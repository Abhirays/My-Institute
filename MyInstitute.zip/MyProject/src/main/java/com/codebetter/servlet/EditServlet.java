package com.codebetter.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.awt.color.ProfileDataException;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import com.codebetter.dao.UserDao;
import com.codebetter.entities.Message;
import com.codebetter.entities.user;
import com.codebetter.helper.ConnectionProvider;
import com.codebetter.helper.Helper;

/**
 * Servlet implementation class EditServlet
 */
@MultipartConfig
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		try(PrintWriter out=response.getWriter()){
			
			//fatch all data
			
			String userEmail = request.getParameter("user_email");
			String userName = request.getParameter("user_name");
			String userPassword = request.getParameter("user_password");
			String userAbout = request.getParameter("user_about");
			Part part = request.getPart("image");
			String imageName=part.getSubmittedFileName();
			
			//get the user from session
			
			HttpSession s = request.getSession();
			user user=(user) s.getAttribute("currentUser");
		    user.setEmail(userEmail);
		    user.setName(userName);
		    user.setPassword(userPassword);
		    user.setAbout(userAbout);
		    String oldFile = user.getProfile();
		    user.setProfile(imageName);
		    
		 //update data to dATABASE....
		    
		    UserDao userDao = new UserDao(ConnectionProvider.getConnection());
		    
		    boolean ans= userDao.UpdateUser(user);
		 if(ans)
		 {
			 String path = getServletContext().getRealPath("/")+"pics"+File.separator+user.getProfile(); 
				
			 //delete code
			 
			 
			String patholdFile = getServletContext().getRealPath("/")+"pics"+File.separator+oldFile; 
			if(!oldFile.equals("default.png")) {
			Helper.deleteFile(patholdFile);
			}
				if(Helper.saveFile(part.getInputStream(), path))
				{
					out.println("Profile updated..");
					Message msg = new Message("Profile details updated..","Success","alert-success");	
					s.setAttribute("msg",msg);
					
				}else {
					 out.println("not save..");
					 Message msg = new Message("Something went Wrong","error","alert-danger");	
						s.setAttribute("msg",msg);
				}
			}
			 
			 
			 
		 
		  else {
			 out.println("not update..");
			 Message msg = new Message("Something went Wrong","error","alert-danger");	
				s.setAttribute("msg",msg);
		 }
		 response.sendRedirect("profile.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
