package com.codebetter.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import com.codebetter.dao.PostDao;
import com.codebetter.entities.Post;
import com.codebetter.entities.user;
import com.codebetter.helper.ConnectionProvider;
import com.codebetter.helper.Helper;

/**
 * Servlet implementation class AddpostServlet
 */
@MultipartConfig
public class AddpostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddpostServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	 try(PrintWriter out=response.getWriter()){
		 
		        String pTitle = request.getParameter("pTitle");
		        String pContent = request.getParameter("pContent");
		        String pCode = request.getParameter("pCode");
		        int cid = Integer.parseInt(request.getParameter("cid"));
		        Part part = request.getPart("pic");
		        
		        HttpSession session = request.getSession();
		        user user =(user) session.getAttribute("currentUser");
		        
		        // Get the Part object for the uploaded file
		        
		        // Get the submitted file name from the Part object
		      //  String fileName = part.getSubmittedFileName();
		        
		        // Create the Post object with the obtained parameters
		        Post p = new Post(pTitle, pContent, pCode, part.getSubmittedFileName(), null, cid, user.getId());
		        
		        PostDao dao = new PostDao(ConnectionProvider.getConnection());
		        if(dao.savePost(p)) {
		            
		    		String path = getServletContext().getRealPath("/")+"blog_pics"+File.separator+part.getSubmittedFileName();
		    		Helper.saveFile(part.getSubmittedFileName(), path);
		    		out.println("done");
		        } else {
		            out.println("error");
		        }
		    }
		}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
