package com.codebetter.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import com.codebetter.dao.UserDao;
import com.codebetter.entities.user;
import com.codebetter.helper.ConnectionProvider;

/**
 * Servlet implementation class Register
 */
@MultipartConfig
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("").append(request.getContextPath());
		try(PrintWriter out=response.getWriter()){

	String check = request.getParameter("check");
	if(check==null)
	{
		out.println("please agree teram and condition");
	}
	else {
		
		//baki ka data yeh niklana...
		
		String name =request.getParameter("user_name");
		System.out.println("name="+name);
		String email=request.getParameter("user_email");
		System.out.println("email="+email);
		String password=request.getParameter("user_password");
		System.out.println("password="+password);
		String gender=request.getParameter("gender");
		System.out.println("gender="+gender);
		String about = request.getParameter("about");
		System.out.println("about="+about);
		//create user object and set all data to that object..
		user user = new user(name,email,password,gender,about);
		//create user dao object..
		UserDao dao = new UserDao(ConnectionProvider.getConnection());
		if(dao.saveuser(user)){
			out.println("done..");
		}else
		{
			out.println("error");
		}
		
	}
		}	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
